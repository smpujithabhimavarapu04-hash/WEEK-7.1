# Java Threads Lab — Experiment 1.1

## Aim
Create three concurrent threads that print:
- `Good Morning` every 1 second
- `Hello` every 2 seconds
- `Welcome` every 3 seconds

The experiment is implemented in two ways: extending `Thread` and implementing `Runnable`.

## Files
- `ThreadExtendsDemo.java` — Method 1: extends `Thread`
- `RunnableDemo.java` — Method 2: implements `Runnable`

## Run on macOS / Linux
Open Terminal in this folder and run:

```bash
javac ThreadExtendsDemo.java
java ThreadExtendsDemo
```

Stop the continuous output with **Ctrl+C**.

For the Runnable version, run separately:

```bash
javac RunnableDemo.java
java RunnableDemo
```

Stop the continuous output with **Ctrl+C**.

## Note
The messages appear in a variable order because the threads execute concurrently. The programs are intended to run continuously until stopped.
